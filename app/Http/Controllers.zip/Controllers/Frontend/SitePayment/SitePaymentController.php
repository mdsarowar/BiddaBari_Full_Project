<?php

namespace App\Http\Controllers\Frontend\SitePayment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SitePaymentController extends Controller
{
    //
}
